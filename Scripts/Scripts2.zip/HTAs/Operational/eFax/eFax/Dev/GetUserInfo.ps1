#GetUserInfo.ps1
#Jeffery Hicks
#jhicks@sapien.com
#http://www.scriptinganswers.com

function Find-User
{
Param ($sam=$(throw "you must enter a sAMAccountname"))
$searcher=New-Object DirectoryServices.DirectorySearcher
$searcher.Filter="(&(objectcategory=person)(objectclass=user)(sAMAccountname="+$sam+"))"
$results=$searcher.FindOne()
if ($results.path.length -gt 1)
     { 
     return $results
     }
    else
     {
     return "Not Found"
     }
 }
 
 $sam=Read-Host "Enter a sAMAccountname"
 $User=Find-User $sam
 if ($User -eq "Not Found") 
    {
     Write-Host -foregroundcolor RED $sam.ToUpper() "was not found in the directory."
    }
    else
    {
     $objUser=$User.GetDirectoryEntry()
#    Show all available user properties
     Write-Host `n
     Write-Host "DN is"$objUser.DistinguishedName
     Write-host "UPN is"$objUser.UserPrincipalName
     Write-host `n
     Write-Host "Other available properties:"
     $objUser|Get-Member
#    Use code like this if you wanted to update a property
#    $objUser.Description="Updated by PowerShell"
#    $objUser.SetInfo()
    }