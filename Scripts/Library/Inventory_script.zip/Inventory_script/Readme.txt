Dell Hardware Inventory Script

------------------------------------------------------------------------------------------------
This script was hacked out by me, WO1 David Hall

I'm not a scripter but I do know how to read and utilize copy and paste.
I also hate wasting time by going desk to desk to get this info. I prefer to do this from the comfort of my own desk
chair.

If you need help with the script let me know, I have no problem helping out

Contact me at david.keith.hall@us.army.mil

The script will retrieve Vendor, Model, Service Tag #, IP address and MAC Address.

-------------------------------------------------------------------------------------------------

Usage:

1. Create a list of IPs in your subnet, it's easy to do in Excel. Should look 
something like this:

192.168.1.2
192.168.1.3
192.168.1.4

save the file to the Inventory_script folder as assets.txt

2. Open a CMD window and navigate to the Inventory_script folder. I'll assume you put it on the root of
the C:\

Command window should look like this:
C:\Inventory_script>

3. Run the script. Should look like this:
C:\Inventory_script>cscript inventory.vbs

Let it roll

Once it's done open the output.csv file and there you go, you just inventoried all machines in your OU.


I do assume a couple of things:

1. You have admin rights on the computers in the assets.txt file.
2. You are inventorying Dell equipment. It works on dell hardware, not sure about Panasonics or IBMs.
