Ping Script
------------------------------------------------------------------------------------------------+
This script was hacked out by me, WO1 David Hall                                                |
                                                                                                |
I'm not a scripter but I do know how to read and utilize copy and paste.                        |
                                                                                                |
If you need help with the script let me know, I have no problem helping out                     |
                                                                                                |
Contact me at david.keith.hall@us.army.mil                                                      |
                                                                                                |
The script will ping the list of computers in the assets.txt file. If the script receives a     |
response it writes the computername in the alive.csv file. If it does not receive a response    |
it writes the computername in the dead.csv file                                                 |
                                                                                                |
------------------------------------------------------------------------------------------------+

Usage:

1. Export a list of computers from your AD OU, computername only. Or you can handjam the list of 
computers, it's up to you. Or you can ping each ip in your subnet. Should look something like this:

name
name1
name2
name3

or

192.168.1.2
192.168.1.3
192.168.1.4


save the file to the Ping_script folder as assets.txt

2. Open a CMD window and navigate to the Ping_script folder. I'll assume you put it on the root of
the C:\

Command window should look like this:
C:\Ping_script>

3. Run the script. Should look like this:
C:\Ping_script>cscript ping.vbs

Let it roll

Once it's done open the alive.csv file and there you go.