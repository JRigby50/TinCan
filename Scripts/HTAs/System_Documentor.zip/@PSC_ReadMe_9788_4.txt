Title: System Documentor Wizard
Description: This HTA grew out of Rene Lariviere's VBS code to document various aspects of Windows machines. He released a 4/5ths-finished version as an HTA and I have used that as a basis for this, adding missing code and replacing other parts with code in my preferred style.<BR><BR>
Having selected or created a list of machine names (or a group name from AD), this HTA will visit each machine in turn (if present on the network) and create an HTML report of various standard items e.g. RAM and hard drives present and allows you to select other items to report, e.g. running services, processes and so on. As each report is based on WMI queries, you can obviously extend the list.<BR><BR>
Hopefully, the code's modularity enables you to plug in extras or edit what's already there to suit your own requirements.
UPDATE:<BR><BR>
- The 'Events' category checkboxes are enabled/disabled according to whether the 'Events' master checkbox is enabled/disabled
- The default 'Last number of 'x' hours' figure works and is preserved between tab switches
- The spin buttons for the above text-box now work
- Non-machine accounts no longer cause the code to summarily exit

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=9788&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
